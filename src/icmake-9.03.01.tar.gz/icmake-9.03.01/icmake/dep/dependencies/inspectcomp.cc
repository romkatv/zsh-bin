#include "dependencies.ih"

void inspectComp(Dependencies *dep
{
    dep->inspect;
    dep->nInspect = 0

    

}
