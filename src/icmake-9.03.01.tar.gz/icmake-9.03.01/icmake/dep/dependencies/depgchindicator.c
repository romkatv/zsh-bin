#include "dependencies.ih"

int *depGchIndicator()
{
    return sdep.d_gchIndicator;
}
