#include "dependencies.ih"

char const *depGch(int idx)
{
    return at(sdep.d_gchPaths, idx);
}
