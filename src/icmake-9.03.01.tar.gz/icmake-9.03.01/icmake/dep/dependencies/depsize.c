#include "dependencies.ih"

int depSize()
{
    return sdep.d_size;
}
