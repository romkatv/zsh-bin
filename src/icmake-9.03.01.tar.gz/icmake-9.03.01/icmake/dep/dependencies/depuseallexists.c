#include "dependencies.ih"

int const *depUseAllExists()
{
    return sdep.d_useAllExists;
}
