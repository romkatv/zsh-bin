#include "options.ih"

char const *optMainih()
{
    return sopts.d_mainih;
}
