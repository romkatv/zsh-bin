#include "options.ih"

char const *optIH()
{
    return sopts.d_ih;
}
