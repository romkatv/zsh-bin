#include "options.ih"

int optGch()
{
    return sopts.d_gch;
}
