#include "options.ih"

char const *optParser()
{
    return sopts.d_parser;
}

