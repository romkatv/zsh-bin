#include "options.ih"

char const *optUseAll()
{
    return sopts.d_use_all;
}
