#include "options.ih"

int optGo()
{
    return sopts.d_go;
}
