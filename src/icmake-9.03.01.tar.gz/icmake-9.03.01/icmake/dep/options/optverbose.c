#include "options.ih"

int optVerbose()
{
    return sopts.d_verbose;
}
