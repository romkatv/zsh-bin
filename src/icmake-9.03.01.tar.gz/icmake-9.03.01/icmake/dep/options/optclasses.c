#include "options.ih"

char const *optClasses()
{
    return sopts.d_classes;
}

