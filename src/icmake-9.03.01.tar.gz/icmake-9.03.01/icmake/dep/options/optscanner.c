#include "options.ih"

char const *optScanner()
{
    return sopts.d_scanner;
}
