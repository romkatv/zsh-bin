#ifndef INCLUDED_PROCESS_
#define INCLUDED_PROCESS_

void ProcessCons();
void processActions();

#endif







