#include "util.ih"

int s_cwd;
Vector s_vector;
