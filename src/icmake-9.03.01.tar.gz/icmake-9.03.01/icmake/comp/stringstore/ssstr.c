
#include "stringstore.ih"

char const *ssStr(unsigned index)
{
    return sp_table[index].str;
}
