
#include "stringstore.ih"

unsigned ssLength(unsigned index)
{
    return strlen(sp_table[index].str);
}
