#include "stringstore.ih"

unsigned    sp_size;
Element    *sp_table;
unsigned    sp_stringSectionSize;   // size of the stringsection
char       *sp_buf;                 // scratch buffer
