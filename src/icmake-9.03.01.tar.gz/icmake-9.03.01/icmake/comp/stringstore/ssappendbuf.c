#include "stringstore.ih"

void ssAppendBuf(char const *str)
{
    sp_buf = rss_strcat(sp_buf, str);
}
