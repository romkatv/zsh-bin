#include "stringstore.ih"

unsigned ssIndex(unsigned index)
{
    return sp_table[index].sectionIndex;
}
