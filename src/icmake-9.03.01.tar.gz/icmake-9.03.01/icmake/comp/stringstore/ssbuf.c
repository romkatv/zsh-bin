
#include "stringstore.ih"

char const *ssBuf()
{
    return sp_buf;
}
