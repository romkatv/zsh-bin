
#include "stringstore.ih"

void ssSetBuf(char const *str)
{
    free(sp_buf);
    sp_buf = rss_strdup(str);
}
