#include "stringstore.ih"

unsigned ssSize()
{
    return sp_size;
}
