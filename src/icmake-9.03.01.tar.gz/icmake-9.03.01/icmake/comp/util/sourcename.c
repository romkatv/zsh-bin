#include "util.ih"

char const *util_sourceName()
{
    return gu_sourceName;
}
