#include "util.ih"

char const *util_string()
{
    return gu_lexstring;
}
