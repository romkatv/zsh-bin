//#define msg
#include "deadcode.ih"

void deadZero()
{
    dp_dead[dp_idx] = 0;
}
