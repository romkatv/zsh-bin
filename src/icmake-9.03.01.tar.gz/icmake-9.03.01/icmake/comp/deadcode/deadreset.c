//#define msgx
#include "deadcode.ih"

void deadReset()
{
    dp_idx = 0;
    dp_dead[0] = 0;
}
