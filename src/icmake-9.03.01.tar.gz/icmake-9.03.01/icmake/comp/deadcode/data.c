//#define XERR
#include "deadcode.ih"

unsigned   *dp_dead;
unsigned   dp_idx;

