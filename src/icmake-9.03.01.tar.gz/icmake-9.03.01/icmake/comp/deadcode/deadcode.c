//#define msg
#include "deadcode.ih"

int deadCode()
{
    return dp_dead[dp_idx];
}
