//#define msg
#include "deadcode.ih"

void deadInc(void)
{
    ++dp_dead[dp_idx];
}
