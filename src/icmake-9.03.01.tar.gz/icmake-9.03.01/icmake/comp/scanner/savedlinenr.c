#include "scanner.ih"

unsigned scanner_savedLineNr()
{
    return gs_savedLineNr;
}
