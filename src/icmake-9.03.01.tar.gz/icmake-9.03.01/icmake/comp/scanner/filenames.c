#include "scanner.ih"

char const *scanner_filenames()
{
    return gs_filenames;
}
