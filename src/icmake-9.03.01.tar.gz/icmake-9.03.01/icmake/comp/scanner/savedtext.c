#include "scanner.ih"

char const *scanner_savedText()
{
    return gs_savedText;
}
