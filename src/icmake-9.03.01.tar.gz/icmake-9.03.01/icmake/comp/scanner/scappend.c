#include "scanner.ih"

void sc_append()
{
    
}
