//#define msgx

#include "semval.ih"

SemVal SVzero()
{
    SemVal ret = {e_null, };
    return ret;
}

