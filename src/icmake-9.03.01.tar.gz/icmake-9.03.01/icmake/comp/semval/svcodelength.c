//#define msgx

#include "semval.ih"

unsigned svCodeLength(SemVal const *sv)
{
    return sv->codelen;
}


