//#define msgx

#include "semval.ih"

ExprType svType(SemVal const *sv)
{
    return sv->type;
}
