//#define msgx

#include "semval.ih"

void svSetValue(SemVal *sv, int value)
{
    sv->value = value;
}

