#include "semval.ih"

int svCopyVar()
{
    return s_lastOpcode == op_copy_var;
}

