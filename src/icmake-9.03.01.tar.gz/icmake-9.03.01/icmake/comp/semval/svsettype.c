//#define msgx

#include "semval.ih"

void svSetType(SemVal *sv, ExprType type)
{
    sv->type = type;
}

