#include "semval.ih"

Opcode s_lastOpcode = op_hlt;

