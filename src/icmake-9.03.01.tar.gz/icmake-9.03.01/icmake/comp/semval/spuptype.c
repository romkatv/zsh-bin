//#define msgx

#include "semval.ih"

void sp_upType(SemVal *sv, int exprTypeOrValue)
{
    sv->type |= exprTypeOrValue;
}







