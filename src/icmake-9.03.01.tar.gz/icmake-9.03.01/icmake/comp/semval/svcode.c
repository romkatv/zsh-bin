//#define msgx

#include "semval.ih"

int8_t const *svCode(SemVal const *sv)
{
    return sv->code;
}

