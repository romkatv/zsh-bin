#include "symtab.ih"

unsigned symtab_nParams()
{
    return gs_vars.nParams;
}
