//#include "parser.ih"
//
//void pmv_clearOperands(SemVal **lval, SemVal *rval)
//{
//    pmv_discard(rval);
//    pmv_discard(*lval);
//    *lval = pmv_stackFrame(e_null);
//}
