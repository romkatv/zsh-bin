//#include "parser.ih"
//
//void p_popVar(SemVal *sv)
//{
//    svOpPopVar(sv);
//    gp_copyVar = 0;
//}
//
