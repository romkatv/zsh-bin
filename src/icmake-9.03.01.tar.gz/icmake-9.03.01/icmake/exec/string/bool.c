#include "string.ih"

int string_bool(String const *lhs)
{
    return *s_str(lhs);
}
