#include "aux.ih"

char const *aux_offset()
{
    return rss_hexString(ga_offset, 4);
}
