#include "aux.ih"

char           *ga_bimname;
unsigned        ga_offset;
struct termios  ga_termios; 

