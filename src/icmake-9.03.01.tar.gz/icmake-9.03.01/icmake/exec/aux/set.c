#include "aux.ih"

void aux_set(unsigned offset)
{
    ga_offset = offset;
}
