#include "list.ih"

int list_bool(ListVariable const *lhs)
{
    return l_size(lhs);
}
