#include "list.ih"

unsigned list_size(ListVariable const *list)
{
    return l_size(list);
}
