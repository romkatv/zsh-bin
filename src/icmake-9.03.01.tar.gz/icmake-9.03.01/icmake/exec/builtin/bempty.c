void b_empty (void)
{}
