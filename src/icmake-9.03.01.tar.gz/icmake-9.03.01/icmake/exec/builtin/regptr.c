#include "builtin.ih"

Variable const *builtin_regPtr()
{
    return &gb_reg;
}
