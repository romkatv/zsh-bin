#include "stack.ih"

Variable   *gs_stack;

unsigned  gs_sp;
unsigned  gs_bp;

