#include "int.h"

void int_assignInt(IntVariable *lhs, int value)
{
    lhs->intValue = value;
}
