#include "int.h"

int int_value(IntVariable const *lhs)
{
    return lhs->intValue;
}
