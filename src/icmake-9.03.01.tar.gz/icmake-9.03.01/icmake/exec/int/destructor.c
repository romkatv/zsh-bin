#include "int.h"

void intDestructor(Variable const *var)
{}

