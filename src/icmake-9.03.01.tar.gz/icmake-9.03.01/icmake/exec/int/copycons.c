#include "int.h"

void intcopycons(IntVariable *var, IntVariable const *other)
{
    *var = *other;
}
