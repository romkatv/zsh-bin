#include "int.h"

int int_bool(IntVariable const *lhs)
{
    return lhs->intValue;
}
