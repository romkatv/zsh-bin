/*
\funcref{fun\_eq}{void fun\_eq ()}
    {}
    {}
    {push(),virtual_compare(), stack_pop()}
    {}
    {funeq.c}
    {

        Function {\em fun\_eq()} is called when opcode {\em op\_eq} is read.
        This function pops two variables, calls {\em compare()} to compare the
        values, and pushes the result of the comparison. The two compared
        variables are discarded.
    }
*/

#include "opcodefun.ih"

void o_eq ()
{
    virtual_compare();
    int_assignInt(stack_top(), int_value(stack_top()) == 0);
}




