#include "opcodefun.ih"

void opcodefun_close()
{
    fclose(go_infile);
}
