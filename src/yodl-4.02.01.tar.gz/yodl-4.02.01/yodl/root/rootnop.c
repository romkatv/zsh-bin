#include "root.ih"

void root_nop(void *vp)
{}
