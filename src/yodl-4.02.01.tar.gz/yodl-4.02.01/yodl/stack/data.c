#include "stack.ih"

StackValue stFailed = {PFAILED};
