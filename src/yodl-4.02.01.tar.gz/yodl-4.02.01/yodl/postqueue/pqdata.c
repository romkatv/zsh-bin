#include "postqueue.ih"

int postqueue_data = 0;

PostQueue postQueue;    /* initialized to 0 by the compiler */
