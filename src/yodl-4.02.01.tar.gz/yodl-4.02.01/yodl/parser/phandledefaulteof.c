#include "parser.ih"

bool p_handle_default_eof(register Parser *pp)
{
    return false;                                       /* done at EOF  */
}
