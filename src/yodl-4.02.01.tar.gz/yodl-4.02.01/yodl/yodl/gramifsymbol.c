#include "yodl.h"

void gram_IFSYMBOL()
{
    parser_if(&parser, SYMBOL, "IFSYMBOL");
}
