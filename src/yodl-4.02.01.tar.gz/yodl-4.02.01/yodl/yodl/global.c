#include "global.h"

#include "../tmp/wip/builtins.def"   /* required by builtin_array[],     */
                                /* created by `build programs' or           */
                                /* `build yodl'                             */

HashMap symtab;
Ostream outs;
Parser  parser;
