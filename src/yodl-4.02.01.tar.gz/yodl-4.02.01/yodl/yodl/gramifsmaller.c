
#include "yodl.h"

void gram_IFSMALLER()
{
    parser_if_cond(&parser, parser_if_smaller, "IFSMALLER", 4);
}
