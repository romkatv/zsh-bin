
#include "yodl.h"

void gram_IFGREATER()
{
    parser_if_cond(&parser, parser_if_greater, "IFGREATER", 4);
}
