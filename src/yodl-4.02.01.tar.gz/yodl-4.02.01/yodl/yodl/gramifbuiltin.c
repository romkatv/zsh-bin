#include "yodl.h"

void gram_IFBUILTIN()
{
    parser_if(&parser, BUILTIN, "IFBUILTIN");
}
