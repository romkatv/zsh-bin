#include "yodl.h"

void gram_POPCOUNTER()
{
    parser_pop(&parser, COUNTER, "POPCOUNTER", "counter");
}
