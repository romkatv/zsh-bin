#include "yodl.h"

void gram_IFDEF()
{
    parser_if(&parser, ANY, "IFDEF");
}
