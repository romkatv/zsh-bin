//                     version.cc

#include "main.ih"

#include "VERSION"

char const version[] = VERSION;
char const author[] = AUTHOR;
char const years[] = YEARS;




