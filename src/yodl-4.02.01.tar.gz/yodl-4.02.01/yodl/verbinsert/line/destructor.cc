#include "line.ih"

Line::~Line()
{
    delete d_in;
}
